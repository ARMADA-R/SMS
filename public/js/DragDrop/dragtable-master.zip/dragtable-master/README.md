jquery dragtable
================
samples : http://akottr.github.io/dragtable

#### Dependencies
* jQuery
* jQuery UI
  * Core
  * Widget
  * Mouse
  * Sortable
